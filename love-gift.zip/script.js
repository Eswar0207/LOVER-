/* ===== Config ===== */
const PIN = '2024';            // <- change your passkey here
const PHOTOS = ['photo-1518199266791-5375a83190b7','photo-1516589178581-6cd7833ae3b2','photo-1529634806980-85c3dd6d34ac',
  'photo-1474552226712-ac0f0961a954','photo-1522673607200-164d1b6ce486','photo-1511988617509-a57c8a288659']
  .map(id => `https://images.unsplash.com/${id}?w=400&q=70&auto=format&fit=crop`);

const $ = id => document.getElementById(id);
const rand = (a, b) => a + Math.random() * (b - a);
const bgm = $('bgm');
let muted = false, entered = '';

/* ===== Helpers ===== */
function show(id){
  document.querySelectorAll('.scene').forEach(s => s.classList.toggle('active', s.id === id));
  $('backBtn').hidden = id !== 's6';
}
// Click sound synthesised with Web Audio (no file needed)
let ac;
function tick(freq = 660){
  if (muted) return;
  ac = ac || new (window.AudioContext || window.webkitAudioContext)();
  const o = ac.createOscillator(), g = ac.createGain();
  o.frequency.value = freq; o.type = 'sine';
  g.gain.setValueAtTime(.15, ac.currentTime); g.gain.exponentialRampToValueAtTime(.001, ac.currentTime + .12);
  o.connect(g).connect(ac.destination); o.start(); o.stop(ac.currentTime + .12);
}
// Layered SVG rose
function rose(size, color){
  let p = '';
  for (let i = 0; i < 5; i++) p += `<ellipse cx="30" cy="30" rx="${26 - i * 4.5}" ry="${22 - i * 4}" fill="${color}" stroke="rgba(124,45,55,.25)" transform="rotate(${i * 38} 30 30)" opacity="${1 - i * .08}"/>`;
  return `<svg viewBox="0 0 60 60" width="${size}" height="${size}">${p}<circle cx="30" cy="30" r="3" fill="#7C2D37" opacity=".5"/></svg>`;
}
const ROSE_COLORS = ['#F2A7B0', '#E0838A', '#F7E3C8', '#FBEFE6', '#F6C4CA'];

/* ===== Ambient dust ===== */
for (let i = 0; i < 28; i++){
  const d = document.createElement('i'), s = rand(3, 9);
  d.style.cssText = `left:${rand(0,100)}%;width:${s}px;height:${s}px;animation-duration:${rand(12,26)}s;animation-delay:-${rand(0,20)}s`;
  $('dust').appendChild(d);
}

/* ===== Scene 1 -> 2 -> 3 ===== */
$('giftBtn').onclick = () => {
  bgm.volume = .5; bgm.play().catch(() => {});   // user gesture unlocks audio
  tick(520);
  const c = $('curtain');
  c.className = '';
  for (let i = 0; i < 70; i++){
    const r = document.createElement('div');
    r.className = 'rose';
    r.style.cssText = `left:${rand(-5,100)}%;--r:${rand(-360,360)}deg;animation-duration:${rand(2,3.6)}s;animation-delay:${rand(0,1.2)}s;filter:blur(${Math.random()<.25?2:0}px)`;
    r.innerHTML = rose(rand(50, 110), ROSE_COLORS[i % 5]);
    c.appendChild(r);
  }
  c.classList.add('cover');
  setTimeout(() => show('s3'), 1800);
  setTimeout(() => c.classList.add('gone'), 2600);
  setTimeout(() => { c.innerHTML = ''; c.className = ''; }, 4200);
};

/* ===== Scene 4: keypad ===== */
const keys = $('keys');
['1','2','3','4','5','6','7','8','9','C','0','⌫'].forEach(k => {
  const b = document.createElement('button');
  b.textContent = k; b.onclick = () => press(k); keys.appendChild(b);
});
function paint(){ [...$('dots').children].forEach((d, i) => d.classList.toggle('on', i < entered.length)); }
function press(k){
  tick(k === 'C' ? 400 : 700);
  if (navigator.vibrate) navigator.vibrate(10);
  if (k === 'C') entered = '';
  else if (k === '⌫') entered = entered.slice(0, -1);
  else if (entered.length < 4) entered += k;
  paint();
  if (entered.length === 4) setTimeout(check, 200);
}
function check(){
  if (entered === PIN){ $('modal').hidden = true; entered = ''; paint(); startLoader(); }
  else {
    const p = $('pad'); p.classList.add('shake'); tick(180);
    setTimeout(() => { p.classList.remove('shake'); entered = ''; paint(); }, 500);
  }
}
$('lockBtn').onclick = () => { tick(); $('modal').hidden = false; };
$('closeBtn').onclick = () => { $('modal').hidden = true; entered = ''; paint(); };
document.addEventListener('keydown', e => {            // desktop keyboard support
  if ($('modal').hidden) return;
  if (/^\d$/.test(e.key)) press(e.key);
  else if (e.key === 'Backspace') press('⌫');
  else if (e.key === 'Escape') $('closeBtn').click();
});

/* ===== Scene 5: loader ===== */
function startLoader(){
  show('s5');
  const ring = $('ring'); ring.innerHTML = '';
  for (let i = 0; i < 14; i++){
    const r = document.createElement('div'); r.className = 'rose';
    const a = i / 14 * 2 * Math.PI;
    r.style.transform = `translate(${Math.cos(a)*85-22}px,${Math.sin(a)*85-22}px)`;
    r.innerHTML = rose(44, i % 2 ? '#FFFFFF' : '#F2A7B0'); ring.appendChild(r);
  }
  $('loadTxt').textContent = 'LOADING';
  setTimeout(() => $('loadTxt').textContent = 'Unlocked ✓', 1800);
  setTimeout(reveal, 3000);
}

/* ===== Scene 6: polaroids + typewriter ===== */
function reveal(){
  show('s6');
  const wall = $('wall'); wall.innerHTML = '';
  PHOTOS.forEach(src => {
    const p = document.createElement('div'); p.className = 'pol';
    p.style.setProperty('--rot', rand(-6, 6).toFixed(1) + 'deg');
    p.innerHTML = `<img src="${src}" alt="Our memory" loading="lazy" onerror="this.removeAttribute('src')">`;
    const tilt = (x, y) => {                       // 3D tilt on mouse / touch
      const r = p.getBoundingClientRect();
      p.style.setProperty('--ry', ((x - r.left) / r.width - .5) * 24 + 'deg');
      p.style.setProperty('--rx', -((y - r.top) / r.height - .5) * 24 + 'deg');
    };
    const reset = () => { p.style.setProperty('--rx', '0deg'); p.style.setProperty('--ry', '0deg'); };
    p.addEventListener('mousemove', e => tilt(e.clientX, e.clientY));
    p.addEventListener('touchmove', e => tilt(e.touches[0].clientX, e.touches[0].clientY), {passive: true});
    ['mouseleave', 'touchend'].forEach(ev => p.addEventListener(ev, reset));
    wall.appendChild(p);
  });
  const el = $('letter'), text = el.dataset.text; el.textContent = ''; el.classList.add('typing');
  let i = 0; clearInterval(reveal.t);
  setTimeout(() => reveal.t = setInterval(() => {
    el.textContent = text.slice(0, ++i);
    if (i >= text.length){ clearInterval(reveal.t); el.classList.remove('typing'); }
  }, 45), 1200);
}
$('backBtn').onclick = () => { clearInterval(reveal.t); $('s6').scrollTop = 0; show('s1'); };

/* ===== Mute ===== */
$('muteBtn').onclick = () => {
  muted = !muted; bgm.muted = muted; $('muteBtn').classList.toggle('off', muted);
  if (!muted && bgm.paused && $('s1').classList.contains('active') === false) bgm.play().catch(() => {});
};

/* ===== Heart cursor trail ===== */
let last = 0;
addEventListener('pointermove', e => {
  const n = performance.now(); if (n - last < 70) return; last = n;
  const h = document.createElement('span'); h.className = 'trail';
  h.textContent = Math.random() < .3 ? '✦' : '♥';
  h.style.cssText = `left:${e.clientX}px;top:${e.clientY}px;font-size:${rand(10,18)}px`;
  document.body.appendChild(h); setTimeout(() => h.remove(), 900);
});
